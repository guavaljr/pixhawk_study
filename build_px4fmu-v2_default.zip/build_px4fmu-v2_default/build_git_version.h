
/* Auto Magically Generated file */
/* Do not edit! */
#pragma once
#define PX4_GIT_VERSION_STR  "02ea10ed99934f219dcea85ad27b7e3e404e02ef"
#define PX4_GIT_VERSION_BINARY 0x02ea10ed99934f21
#define PX4_GIT_TAG_STR  "v1.6.5-273-g02ea10ed9-dirty"
#define PX4_GIT_BRANCH_NAME  "master"

#define NUTTX_GIT_VERSION_STR  "8b81cf5c7ece0c228eaaea3e9d8e667fc4d21a06"
#define NUTTX_GIT_VERSION_BINARY 0x8b81cf5c7ece0c22
#define NUTTX_GIT_TAG_STR  "v7.18.0"

#define MAVLINK_LIB_GIT_VERSION_STR  "646c3f4eeae648ffb2cc7dca041d414c4b42c88a"
#define MAVLINK_LIB_GIT_VERSION_BINARY 0x646c3f4eeae648ff
