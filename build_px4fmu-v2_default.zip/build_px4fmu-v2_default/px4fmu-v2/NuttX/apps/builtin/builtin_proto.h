int cu_main(int argc, char *argv[]);
int sercon_main(int argc, char *argv[]);
int serdis_main(int argc, char *argv[]);
