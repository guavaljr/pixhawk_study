External Libraries
^^^^^^^^^^^^^^^^^^

  The apps/gpsutils directory is used to include libraries from external
  projects that are not part of NuttX Applications, but are useful for NuttX
  developers and users.

gpsutils/minmea
^^^^^^^^^^^^^^^^^^

  MINMEA is a NMEA parser developed by Kosma Moczek. Kosma is also a NuttX
  contributor.
